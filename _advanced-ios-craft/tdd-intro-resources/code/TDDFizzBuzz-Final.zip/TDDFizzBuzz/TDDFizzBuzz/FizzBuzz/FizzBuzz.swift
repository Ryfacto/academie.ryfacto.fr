//
//  Created by Nicolas VERINAUD on 18/07/2019.
//  Copyright © 2019 Ryfacto. All rights reserved.
//

import Foundation

struct FizzBuzz {
  
  func upTo(_ n: UInt) -> [String] {
    return (0...n).dropFirst(1).map(stringFor)
  }
  
  private func stringFor(_ n: UInt) -> String {
    if n.isMultipleOf3 && n.isMultipleOf5 { return "FizzBuzz" }
    if n.isMultipleOf3 { return "Fizz" }
    if n.isMultipleOf5 { return "Buzz" }
    return "\(n)"
  }
}

extension UInt {
  
  var isMultipleOf3: Bool {
    return self % 3 == 0
  }
  
  var isMultipleOf5: Bool {
    return self % 5 == 0
  }
}
