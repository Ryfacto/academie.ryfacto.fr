//
//  Created by Nicolas VERINAUD on 17/07/2019.
//  Copyright © 2019 Ryfacto. All rights reserved.
//

import XCTest
@testable import TDDFizzBuzz

class FizzBuzz_Spec: XCTestCase {
  
  func test_FizzBuzz_up_to_0_is_an_empty_list() {
    assertThatFizzBuzz(upTo: 0, is: [])
  }
  
  func test_Result_list_is_of_the_same_size_as_requested_upper_bound() {
    let fizzBuzz = FizzBuzz()
    for n in 0...100 {
      let result = fizzBuzz.upTo(UInt(n))
      XCTAssertEqual(n, result.count)
    }
  }
  
  func test_Numbers_not_multiple_of_3_or_5_are_displayed_as_is() {
    let expectations: [UInt: String] = [ 1: "1", 2: "2", 4: "4", 10213: "10213" ]
    for (n, expected) in expectations {
      assertThatFizzBuzz(upTo: n, endsWith: expected)
    }
  }
  
  func test_Multiples_of_3_but_not_5_are_displayed_as_Fizz() {
    assertThatAllFizzBuzzUpTo([ 3, 6, 9, 12, 18, UInt(3 * 123) ], endsWith: "Fizz")
  }
  
  func test_Multiples_of_5_but_not_3_are_displayed_as_Buzz() {
    assertThatAllFizzBuzzUpTo([ 5, 10, 20, 25, 35, UInt(5 * 124) ], endsWith: "Buzz")
  }
  
  func test_Multiples_of_3_and_5_are_displayed_as_FizzBuzz() {
    assertThatAllFizzBuzzUpTo([ 15, 30, 45, 60, 75, 90, UInt(3 * 5 * 125) ], endsWith: "FizzBuzz")
  }
  
  func test_Print_numbers_from_1_to_100() {
    assertThatFizzBuzz(upTo: 100, is: [ "1", "2", "Fizz", "4", "Buzz", "Fizz", "7", "8", "Fizz", "Buzz", "11", "Fizz", "13", "14", "FizzBuzz", "16", "17", "Fizz", "19", "Buzz", "Fizz", "22", "23", "Fizz", "Buzz", "26", "Fizz", "28", "29", "FizzBuzz", "31", "32", "Fizz", "34", "Buzz", "Fizz", "37", "38", "Fizz", "Buzz", "41", "Fizz", "43", "44", "FizzBuzz", "46", "47", "Fizz", "49", "Buzz", "Fizz", "52", "53", "Fizz", "Buzz", "56", "Fizz", "58", "59", "FizzBuzz", "61", "62", "Fizz", "64", "Buzz", "Fizz", "67", "68", "Fizz", "Buzz", "71", "Fizz", "73", "74", "FizzBuzz", "76", "77", "Fizz", "79", "Buzz", "Fizz", "82", "83", "Fizz", "Buzz", "86", "Fizz", "88", "89", "FizzBuzz", "91", "92", "Fizz", "94", "Buzz", "Fizz", "97", "98", "Fizz", "Buzz" ])
  }
  
  private func assertThatFizzBuzz(upTo n: UInt, is expected: [String], line: UInt = #line) {
    let result = fizzBuzz(upTo: n)
    XCTAssertEqual(expected, result, line: line)
  }
  
  private func assertThatFizzBuzz(upTo n: UInt, endsWith expected: String, line: UInt = #line) {
    let result = fizzBuzz(upTo: n)
    XCTAssertEqual(expected, result.last, line: line)
  }
  
  private func assertThatAllFizzBuzzUpTo(_ examples: [UInt], endsWith expected: String, line: UInt = #line) {
    for n in examples {
      assertThatFizzBuzz(upTo: n, endsWith: expected, line: line)
    }
  }
  
  private func fizzBuzz(upTo n: UInt) -> [String] {
    let fizzBuzz = FizzBuzz()
    return fizzBuzz.upTo(n)
  }
}
