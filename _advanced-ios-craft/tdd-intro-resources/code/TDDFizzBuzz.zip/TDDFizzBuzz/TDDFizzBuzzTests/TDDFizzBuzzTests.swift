//
//  Created by Nicolas VERINAUD on 16/07/2019.
//  Copyright © 2019 Ryfacto. All rights reserved.
//

import XCTest
@testable import TDDFizzBuzz

class TDDFizzBuzzTests: XCTestCase {

    func testExample() {
    }
}
